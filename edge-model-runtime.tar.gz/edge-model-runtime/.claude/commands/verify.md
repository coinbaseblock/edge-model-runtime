---
description: Health check — containers, GPU, APIs, disk
---

```bash
bash scripts/03-verify.sh
```

Then briefly summarize:
- Container statuses
- Whether the GPU is accessible
- Ollama and WebUI reachability
- Top 3 disk consumers under `${AI_DATA_ROOT}`

Flag anything not green and propose the next step.
