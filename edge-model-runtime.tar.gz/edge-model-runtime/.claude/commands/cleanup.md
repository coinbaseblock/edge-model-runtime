---
description: Level 2 cleanup — remove containers/images, keep models
---

This is the safe-to-run cleanup. Models on the host are preserved.

```bash
bash scripts/10-cleanup-docker.sh
```

For total wipe (including models), the user must run `bash scripts/20-wipe-models.sh` themselves — that command is in the deny list and Claude will not run it.
