---
description: Stop the runtime (models preserved)
---

```bash
bash scripts/02-stop.sh
```
