---
description: List installed Ollama models
---

```bash
bash scripts/05-list-models.sh
```
