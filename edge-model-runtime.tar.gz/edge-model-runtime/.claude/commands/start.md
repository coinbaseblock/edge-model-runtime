---
description: Start the runtime
---

```bash
bash scripts/01-start.sh
```

If anything fails, run `docker compose logs --tail=50` and diagnose.
