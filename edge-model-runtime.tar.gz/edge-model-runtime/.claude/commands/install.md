---
description: Run first-time installation
---

Run the install script and report the result.

```bash
bash scripts/00-install.sh
```

After it completes, run `bash scripts/03-verify.sh` and summarize:
- Whether all containers are healthy
- Which Docker images are installed
- WebUI URL and Ollama API URL
- Suggest the user pull a starter model with `/pull qwen2.5-coder:7b`
