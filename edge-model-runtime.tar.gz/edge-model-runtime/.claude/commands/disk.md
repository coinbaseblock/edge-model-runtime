---
description: Disk usage report
---

```bash
bash scripts/08-disk-report.sh
```

If the data root is over 80% full, suggest:
1. Removing unused models with `/cleanup` or `bash scripts/06-remove-model.sh <name>`
2. Smaller quantizations (q4_K_M instead of q8_0)
