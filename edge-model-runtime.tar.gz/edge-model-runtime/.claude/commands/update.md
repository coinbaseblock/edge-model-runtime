---
description: Update Docker images to versions in .env.versions
---

Show current image tags from `.env.versions`, then run:

```bash
bash scripts/09-update-images.sh
```

Verify the upgrade with `bash scripts/03-verify.sh`. Models on the host are preserved.
