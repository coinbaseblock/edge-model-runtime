---
description: Pull an Ollama model
argument-hint: <model[:tag]>
---

Pull the model `$ARGUMENTS`. If no argument was given, suggest reasonable defaults from `docs/MODEL-RECOMMENDATIONS.md` based on the user's context.

```bash
bash scripts/04-pull-model.sh $ARGUMENTS
```

After the pull, report total disk used by `${AI_DATA_ROOT}/ollama` and the new model count.
