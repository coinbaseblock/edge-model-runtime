# Claude Code integration

This repo is set up to work cleanly with [Claude Code](https://claude.com/claude-code).

## Files

- `CLAUDE.md` (repo root) — context loaded into every Claude Code session. Explains invariants, conventions, and where to push back.
- `.claude/settings.json` — permissions (allow safe ops, deny destructive ones by default).
- `.claude/commands/*.md` — slash commands invokable inside Claude Code.

## Slash commands

Inside a Claude Code session in this repo:

| Command | Action |
|---|---|
| `/install` | Run `scripts/00-install.sh` |
| `/start` | Run `scripts/01-start.sh` |
| `/stop` | Run `scripts/02-stop.sh` |
| `/verify` | Run `scripts/03-verify.sh` |
| `/pull <model>` | Pull a model |
| `/list-models` | List installed models |
| `/disk` | Disk report |
| `/update` | Update images |
| `/cleanup` | Level 2 cleanup |

## Permission model

`settings.json` denies destructive operations by default:

- Wipe script (`20-wipe-models.sh`) — Claude must ask the user to run it manually.
- `rm -rf` on `/mnt/edge-backup/` — denied outright.
- Editing `.env` (which contains the secret key) — denied.

The user can always override by approving a one-off command in the Claude Code UI.

## Recommended workflow

1. Open the repo in Claude Code.
2. Ask Claude to run `/verify` to baseline the state.
3. Describe what you want changed.
4. Claude edits files; you review the diff; approve.
5. Claude runs the relevant lifecycle script (`/start`, `/update`, etc.) and confirms via `/verify`.

For destructive changes (`20-wipe-models.sh`, etc.), Claude will print the exact command and ask you to run it yourself.
